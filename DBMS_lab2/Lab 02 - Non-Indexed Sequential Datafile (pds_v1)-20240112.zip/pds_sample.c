#include<stdio.h>
#include<string.h>
#include<errno.h>
#include<stdlib.h>


// Define the global variable
struct PDS_RepoInfo repo_handle;

int pds_open( char *repo_name, int rec_size  )
{
// Open data files as per the following convention
// If repo_name is "demo", then data file should be "demo.dat"
// Initialize other members of PDS_RepoInfo

}

int put_rec_by_key( int key, struct Contact *rec )
{
// Seek to the end of the data file
// Write the record at the current file location
}

int get_rec_by_key( int key, struct Contact *rec )
{
 // Read record-record-by record from data file
 // Compare key of the record with the given key
 // Return success status if record is found else return failure status 
}

int pds_close()
{
// Close the repo file
// Update file pointer and status in global struct
}
