# include <stdio.h> 

struct student {
  int rollnum;
  char name[30];
  int age;
};

int save_num_text( char *filename ) {
//write your code
}

int read_num_text( char *filename ) {
  //write your code
}

int save_struct_text( char *filename ) {
  //write your code
}

int read_struct_text( char *filename ) {
//write your code
}


int save_num_binary( char *filename ) {
//write your code
}

int read_num_binary( char *filename ) {
 //write your code
}

int save_struct_binary( char *filename ) {
  //write your code
}

int read_struct_binary( char *filename ) {
 //write your code
}

